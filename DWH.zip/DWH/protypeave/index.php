<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/m1.css"/>
<title>Inicio de Sesión</title>
</head>
<body>
	<form name="form1" method="post" action="back_code/login.php" class="login">
    
        <img id="imgagen" src="img/AVE.png" alt="ave" width="192" height="100" align="middle"/>           
  		<div id="enter">	
     		<input type="text" name="USR" id="USR" placeholder="usuario" required="required"/>
          	<input type="password" name="PASS" id="PASS" placeholder="contraseña" required="required"/>
        </div>
       
  		<div id="boton">
        	<input type="submit" name="Entrar" id="boton" value="Enviar" />
   		</div>
	</form>
</body>
</html>