<?php 
	include 'back_code/Mysql.class.php';
  	conectar();
	$E_LLANTAS = $_GET['variable']; 
	$options='';
	
	//echo "El identificador de este cliente es: $E_LLANTAS"; 
	$ssql = 'SELECT distinct(ID_MARCA),MARCA,sum(COSTO), count(*) FROM ave_t_llanta ';
	$ssql .= 'WHERE ESTATUS  = "'.$E_LLANTAS;
	$ssql .= '" Group by ID_MARCA, MARCA order by 3 desc ';
	//echo "$ssql";
	$options = ' <div id="tabla_llantas_grafica" class="ConsultarLlantasGrafica" >
				 <table  border="1" id="tbConsulta" name="tbConsulta">
                    <tr>
                        <td>Estatus</td>
						<td>cantidad</td>
                        <td>Costo</td>
                     </tr>';
	
	$query = mysql_query( $ssql);
	//echo "$query";
	
	/**/
	 if ($query){
		while ($resultado = mysql_fetch_row($query)){
			//if($resultado[0]){
				$options .= '<tr><td><p align="center">'.$resultado[1].'</p></td>'; //Marca
				$options .= '<td><p align="center">'.$resultado[3].'</p></td>'; //Marca
				$options .= '<td><p align="center">$'.number_format($resultado[2], 2).'</td></tr>'; //Costo
				
				//}
				
			}
			$options .= '</table></div>';
			echo $options;
		}
?>
